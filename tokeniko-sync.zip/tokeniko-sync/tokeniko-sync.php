<?php
/**
 * Plugin Name: Tokeniko WooCommerce Sync
 * Description: همگام‌سازی خودکار محصولات و جواهرات توکنیکو با ووکامرس هر ۱۵ دقیقه، با تبدیل ریال به تومان و درصد سود قابل تنظیم.
 * Version: 1.1.0
 * Author: h.vahedi_call me:+989164672796
 * Text Domain: tokeniko-sync
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'TOKENIKO_SYNC_PATH', plugin_dir_path( __FILE__ ) );
define( 'TOKENIKO_SYNC_URL', plugin_dir_url( __FILE__ ) );
define( 'TOKENIKO_SYNC_VERSION', '1.1.0' );
define( 'TOKENIKO_SYNC_OPTION_PROFIT', 'tokeniko_sync_profit_percent' );

require_once TOKENIKO_SYNC_PATH . 'includes/class-tokeniko-sync-api.php';
require_once TOKENIKO_SYNC_PATH . 'includes/class-tokeniko-sync-products.php';
require_once TOKENIKO_SYNC_PATH . 'includes/class-tokeniko-sync-cron.php';

class Tokeniko_Sync_Plugin {

    public function __construct() {
        add_filter( 'cron_schedules', [ $this, 'add_cron_interval' ] );

        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );

        add_action( 'admin_menu', [ $this, 'register_admin_page' ] );
    }

    public function add_cron_interval( $schedules ) {
        if ( ! isset( $schedules['fifteen_minutes'] ) ) {
            $schedules['fifteen_minutes'] = [
                'interval' => 900,
                'display'  => __( 'Every 15 Minutes', 'tokeniko-sync' ),
            ];
        }
        return $schedules;
    }

    public function activate() {
        if ( ! wp_next_scheduled( 'tokeniko_sync_event' ) ) {
            wp_schedule_event( time(), 'fifteen_minutes', 'tokeniko_sync_event' );
        }

        // مقدار پیش‌فرض سود: ۰ درصد
        if ( get_option( TOKENIKO_SYNC_OPTION_PROFIT, null ) === null ) {
            update_option( TOKENIKO_SYNC_OPTION_PROFIT, 0 );
        }
    }

    public function deactivate() {
        $timestamp = wp_next_scheduled( 'tokeniko_sync_event' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'tokeniko_sync_event' );
        }
    }

    public function register_admin_page() {
        add_menu_page(
            __( 'Tokeniko Sync', 'tokeniko-sync' ),
            __( 'Tokeniko Sync', 'tokeniko-sync' ),
            'manage_woocommerce',
            'tokeniko-sync',
            [ $this, 'render_admin_page' ],
            'dashicons-update',
            56
        );
    }

    public function render_admin_page() {

        // ذخیره درصد سود
        if ( isset( $_POST['tokeniko_profit_save'] ) && check_admin_referer( 'tokeniko_profit_action', 'tokeniko_profit_nonce' ) ) {
            $profit = isset( $_POST['tokeniko_profit_percent'] ) ? floatval( $_POST['tokeniko_profit_percent'] ) : 0;
            if ( $profit < 0 ) {
                $profit = 0;
            }
            update_option( TOKENIKO_SYNC_OPTION_PROFIT, $profit );
            echo '<div class="updated"><p>درصد سود با موفقیت ذخیره شد.</p></div>';
        }

        // همگام‌سازی دستی
        if ( isset( $_POST['tokeniko_manual_sync'] ) && check_admin_referer( 'tokeniko_manual_sync_action', 'tokeniko_manual_sync_nonce' ) ) {
            do_action( 'tokeniko_sync_run' );
            echo '<div class="updated"><p>همگام‌سازی دستی انجام شد.</p></div>';
        }

        $current_profit = floatval( get_option( TOKENIKO_SYNC_OPTION_PROFIT, 0 ) );
        ?>
        <div class="wrap">
            <h1>Tokeniko WooCommerce Sync</h1>

            <h2>تنظیم درصد سود</h2>
            <form method="post">
                <?php wp_nonce_field( 'tokeniko_profit_action', 'tokeniko_profit_nonce' ); ?>
                <p>
                    <label for="tokeniko_profit_percent">درصد سود (مثلاً ۱۰ برای ۱۰٪):</label>
                    <input type="number" step="0.01" min="0" id="tokeniko_profit_percent" name="tokeniko_profit_percent" value="<?php echo esc_attr( $current_profit ); ?>" />
                </p>
                <p><button class="button button-primary" name="tokeniko_profit_save" value="1">ذخیره درصد سود</button></p>
            </form>

            <hr>

            <h2>همگام‌سازی دستی</h2>
            <form method="post">
                <?php wp_nonce_field( 'tokeniko_manual_sync_action', 'tokeniko_manual_sync_nonce' ); ?>
                <p>برای اجرای دستی همگام‌سازی با API توکنیکو روی دکمه زیر کلیک کنید.</p>
                <p><button class="button button-secondary" name="tokeniko_manual_sync" value="1">همگام‌سازی دستی</button></p>
            </form>
        </div>
        <?php
    }
}

new Tokeniko_Sync_Plugin();

// Cron handler
add_action( 'tokeniko_sync_event', 'tokeniko_sync_run_cron' );
add_action( 'tokeniko_sync_run', 'tokeniko_sync_run_cron' );

function tokeniko_sync_run_cron() {
    $api      = new Tokeniko_Sync_API();
    $products = new Tokeniko_Sync_Products();

    // API 1: محصولات فلزی
    $data1 = $api->get_categories_prices();
    if ( $data1 && isset( $data1['Model'] ) && is_array( $data1['Model'] ) ) {
        $products->sync_from_categories_prices( $data1['Model'] );
    }

    // API 2: جواهرات
    $data2 = $api->get_jewelry_catalog_prices();
    if ( $data2 && isset( $data2['Model'] ) && is_array( $data2['Model'] ) ) {
        $products->sync_from_jewelry_catalog( $data2['Model'] );
    }
}
