<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Tokeniko_Sync_Cron {
    // فعلاً خالی؛ در صورت نیاز می‌توانیم مدیریت پیشرفته کرون و لاگ را اینجا اضافه کنیم.
}
