<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Tokeniko_Sync_API {

    private $endpoint_categories = 'http://apigateway.tokeniko.com/shop/api/categories/prices/0/30000000000/';
    private $endpoint_jewelry   = 'https://apigateway.tokeniko.com/shop/api/catalogs/GetJewelryCatalogPrices';

    public function get_categories_prices() {
        $response = wp_remote_get( $this->endpoint_categories, [
            'timeout' => 30,
        ] );

        if ( is_wp_error( $response ) ) {
            error_log( 'Tokeniko Sync API Error (categories): ' . $response->get_error_message() );
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            error_log( 'Tokeniko Sync JSON Error (categories): ' . json_last_error_msg() );
            return null;
        }

        return $data;
    }

    public function get_jewelry_catalog_prices() {
        $response = wp_remote_get( $this->endpoint_jewelry, [
            'timeout' => 30,
        ] );

        if ( is_wp_error( $response ) ) {
            error_log( 'Tokeniko Sync API Error (jewelry): ' . $response->get_error_message() );
            return null;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            error_log( 'Tokeniko Sync JSON Error (jewelry): ' . json_last_error_msg() );
            return null;
        }

        return $data;
    }
}
