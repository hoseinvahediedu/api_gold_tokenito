<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Tokeniko_Sync_Products {

    private $meta_key_id   = '_tokeniko_id';
    private $meta_key_type = '_tokeniko_type'; // bullion / jewelry

    public function __construct() {
        if ( ! class_exists( 'WC_Product' ) ) {
            return;
        }
    }

    private function apply_price_logic( $raw_price_riel ) {
        // ۱) تبدیل ریال به تومان
        $price = floatval( $raw_price_riel ) / 10;

        // ۲) اعمال درصد سود
        $profit_percent = floatval( get_option( TOKENIKO_SYNC_OPTION_PROFIT, 0 ) );
        if ( $profit_percent > 0 ) {
            $price = $price + ( $price * $profit_percent / 100 );
        }

        return $price;
    }

    public function sync_from_categories_prices( $items ) {
        if ( ! is_array( $items ) ) {
            return;
        }

        $seen_ids = [];

        foreach ( $items as $item ) {
            if ( ! isset( $item['Id'] ) && ! isset( $item['ProductId'] ) ) {
                continue;
            }

            $tokeniko_id = isset( $item['ProductId'] ) ? $item['ProductId'] : $item['Id'];
            $seen_ids[]  = $tokeniko_id;

            $title       = isset( $item['Title'] ) ? $item['Title'] : 'محصول بدون نام';
            $raw_price   = isset( $item['SellPrice'] ) ? $item['SellPrice'] : 0;
            $price       = $this->apply_price_logic( $raw_price );
            $image_url   = isset( $item['ImageUrl'] ) ? $item['ImageUrl'] : '';
            $material    = isset( $item['MaterialTitle'] ) ? $item['MaterialTitle'] : '';
            $appearance  = isset( $item['AppearanceTitle'] ) ? $item['AppearanceTitle'] : '';
            $grams       = isset( $item['Grams'] ) ? floatval( $item['Grams'] ) : 0;
            $state_title = isset( $item['CategoryStateTitle'] ) ? $item['CategoryStateTitle'] : '';

            $product_id = $this->get_product_by_tokeniko_id( $tokeniko_id, 'bullion' );

            if ( $product_id ) {
                $product = wc_get_product( $product_id );
            } else {
                $product = new WC_Product_Simple();
            }

            $product->set_name( $title );
            $product->set_regular_price( $price );
            $product->set_catalog_visibility( 'visible' );
            $product->set_status( ( $state_title === 'موجود' ) ? 'publish' : 'draft' );

            if ( $grams > 0 ) {
                $product->set_weight( $grams );
            }

            $categories = $this->build_categories_for_bullion( $material, $appearance );
            if ( ! empty( $categories ) ) {
                $product->set_category_ids( $categories );
            }

            $product_id = $product->save();

            update_post_meta( $product_id, $this->meta_key_id, $tokeniko_id );
            update_post_meta( $product_id, $this->meta_key_type, 'bullion' );

            if ( $image_url ) {
                $this->set_product_image_from_url( $product_id, $image_url );
            }
        }

        // در صورت نیاز می‌توانیم محصولات حذف‌شده را غیرفعال کنیم
        // $this->disable_missing_products( $seen_ids, 'bullion' );
    }

    public function sync_from_jewelry_catalog( $items ) {
        if ( ! is_array( $items ) ) {
            return;
        }

        $seen_ids = [];

        foreach ( $items as $item ) {
            if ( ! isset( $item['CatalogId'] ) ) {
                continue;
            }

            $tokeniko_id = $item['CatalogId'];
            $seen_ids[]  = $tokeniko_id;

            $title     = isset( $item['Title'] ) ? $item['Title'] : 'جواهر بدون نام';
            $min_raw   = isset( $item['MinPrice'] ) ? $item['MinPrice'] : 0;
            $max_raw   = isset( $item['MaxPrice'] ) ? $item['MaxPrice'] : 0;

            $min_price = $min_raw ? $this->apply_price_logic( $min_raw ) : 0;
            $max_price = $max_raw ? $this->apply_price_logic( $max_raw ) : 0;

            $image_url = isset( $item['ImageUrl'] ) ? $item['ImageUrl'] : '';
            $url       = isset( $item['Url'] ) ? $item['Url'] : '';

            $product_id = $this->get_product_by_tokeniko_id( $tokeniko_id, 'jewelry' );

            if ( $product_id ) {
                $product = wc_get_product( $product_id );
            } else {
                $product = new WC_Product_Simple();
            }

            $product->set_name( $title );

            if ( $min_price > 0 ) {
                $product->set_regular_price( $min_price );
            }

            $desc = '';
            if ( $min_price > 0 && $max_price > 0 ) {
                $desc .= 'بازه قیمت تقریبی (با سود): ' . wc_price( $min_price ) . ' تا ' . wc_price( $max_price ) . "<br>";
            }
            if ( $url ) {
                $desc .= 'لینک کاتالوگ: ' . esc_url( $url );
            }

            if ( $desc ) {
                $product->set_description( $desc );
            }

            $product->set_catalog_visibility( 'visible' );
            $product->set_status( 'publish' );

            $categories = $this->build_categories_for_jewelry( $title );
            if ( ! empty( $categories ) ) {
                $product->set_category_ids( $categories );
            }

            $product_id = $product->save();

            update_post_meta( $product_id, $this->meta_key_id, $tokeniko_id );
            update_post_meta( $product_id, $this->meta_key_type, 'jewelry' );

            if ( $image_url ) {
                $this->set_product_image_from_url( $product_id, $image_url );
            }
        }

        // $this->disable_missing_products( $seen_ids, 'jewelry' );
    }

    private function get_product_by_tokeniko_id( $tokeniko_id, $type ) {
        $args = [
            'post_type'  => 'product',
            'meta_query' => [
                'relation' => 'AND',
                [
                    'key'   => $this->meta_key_id,
                    'value' => $tokeniko_id,
                ],
                [
                    'key'   => $this->meta_key_type,
                    'value' => $type,
                ],
            ],
            'fields'         => 'ids',
            'posts_per_page' => 1,
        ];

        $q = new WP_Query( $args );
        if ( $q->have_posts() ) {
            return $q->posts[0];
        }

        return 0;
    }

    private function build_categories_for_bullion( $material, $appearance ) {
        $cats = [];

        $parent_name = 'محصولات فلزی';
        $parent_id   = $this->ensure_term( $parent_name, 'product_cat' );

        if ( $material ) {
            $mat_id = $this->ensure_term( $material, 'product_cat', $parent_id );
            $cats[] = $mat_id;

            if ( $appearance ) {
                $app_name = $appearance . ' ' . $material;
                $app_id   = $this->ensure_term( $app_name, 'product_cat', $mat_id );
                $cats[]   = $app_id;
            }
        }

        return array_unique( $cats );
    }

    private function build_categories_for_jewelry( $title ) {
        $cats = [];

        $parent_name = 'جواهرات طلا';
        $parent_id   = $this->ensure_term( $parent_name, 'product_cat' );

        $sub = null;
        if ( strpos( $title, 'دستبند' ) !== false ) {
            $sub = 'دستبند طلا';
        } elseif ( strpos( $title, 'گوشواره' ) !== false ) {
            $sub = 'گوشواره طلا';
        } elseif ( strpos( $title, 'پلاک' ) !== false ) {
            $sub = 'پلاک طلا';
        } elseif ( strpos( $title, 'انگشتر' ) !== false ) {
            $sub = 'انگشتر طلا';
        } elseif ( strpos( $title, 'زنجیر' ) !== false ) {
            $sub = 'زنجیر طلا';
        }

        if ( $sub ) {
            $sub_id = $this->ensure_term( $sub, 'product_cat', $parent_id );
            $cats[] = $sub_id;
        } else {
            $cats[] = $parent_id;
        }

        return array_unique( $cats );
    }

    private function ensure_term( $name, $taxonomy, $parent = 0 ) {
        $term = get_term_by( 'name', $name, $taxonomy );
        if ( $term ) {
            return $term->term_id;
        }

        $args = [];
        if ( $parent ) {
            $args['parent'] = $parent;
        }

        $result = wp_insert_term( $name, $taxonomy, $args );
        if ( is_wp_error( $result ) ) {
            return 0;
        }

        return $result['term_id'];
    }

    private function set_product_image_from_url( $product_id, $image_url ) {
        if ( ! $image_url ) {
            return;
        }

        $attachment_id = $this->media_sideload_image_as_attachment( $image_url, $product_id );
        if ( $attachment_id && ! is_wp_error( $attachment_id ) ) {
            set_post_thumbnail( $product_id, $attachment_id );
        }
    }

    private function media_sideload_image_as_attachment( $file, $post_id ) {

    if ( ! function_exists( 'media_handle_sideload' ) ) {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    // مرحله ۱: دانلود فایل با CURL دستی
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $file);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    $data = curl_exec($ch);

    if (curl_errno($ch)) {
        error_log("TOKENIKO CURL ERROR: " . curl_error($ch));
        curl_close($ch);
        return new WP_Error('curl_error', curl_error($ch));
    }

    curl_close($ch);

    if (!$data) {
        error_log("TOKENIKO CURL ERROR: empty data");
        return new WP_Error('empty_data', 'Downloaded data is empty');
    }

    // مرحله ۲: ساخت فایل موقت
    $tmp = wp_tempnam($file);
    if (!$tmp) {
        error_log("TOKENIKO TEMP ERROR: cannot create temp file");
        return new WP_Error('temp_error', 'Cannot create temp file');
    }

    file_put_contents($tmp, $data);

    // مرحله ۳: ساخت آرایه فایل برای sideload
    $file_array = [
        'name'     => basename(parse_url($file, PHP_URL_PATH)),
        'tmp_name' => $tmp,
    ];

    // مرحله ۴: آپلود به وردپرس
    $id = media_handle_sideload($file_array, $post_id);

    if (is_wp_error($id)) {
        @unlink($tmp);
        error_log("TOKENIKO SIDELoad ERROR: " . $id->get_error_message());
        return $id;
    }

    return $id;
}


    private function disable_missing_products( $seen_ids, $type ) {
        if ( empty( $seen_ids ) ) {
            return;
        }

        $args = [
            'post_type'      => 'product',
            'posts_per_page' => -1,
            'meta_query'     => [
                [
                    'key'   => $this->meta_key_type,
                    'value' => $type,
                ],
            ],
            'fields' => 'ids',
        ];

        $q = new WP_Query( $args );
        if ( $q->have_posts() ) {
            foreach ( $q->posts as $pid ) {
                $tid = get_post_meta( $pid, $this->meta_key_id, true );
                if ( $tid && ! in_array( $tid, $seen_ids ) ) {
                    $product = wc_get_product( $pid );
                    if ( $product ) {
                        $product->set_status( 'draft' );
                        $product->save();
                    }
                }
            }
        }
    }
}
